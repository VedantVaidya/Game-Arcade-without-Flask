function arfa(){
    a=document.getElementById("image").src="static/arfa.png";
}

function vedant(){
    a=document.getElementById("image").src="static/vedant.png";
}

function parag(){
    a=document.getElementById("image").src="static/parag.png";
}

function sneha(){
    a=document.getElementById("image").src="static/sneha.png";
}

function rajani(){
    a=document.getElementById("image").src="static/rajani.png";
}

function chaitanya(){
    a=document.getElementById("image").src="static/chaitanya.png";
}

function pallavi(){
    a=document.getElementById("image").src="static/pallavi.png";
}